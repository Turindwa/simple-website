<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<title> Home Page </title>
<style>
    body {
        background-color: rgb(102, 102, 124);
        margin:0;
        padding:0;
    }
</style>
</head>
<body>
    <h1>Welcome again!</h1>
    <p>We are so glad and thank you for letting us collect all the rubbish around you.</p>
    <p>Please fill the form below for us to know where to find you.Thank you</p>
    <div>
    <form>

        <label> Firstname </label>
        <input type="text" name="firstname" size="15"/> <br> <br>
        <label> Middlename: </label>
        <input type="text" name="middlename" size="15"/> <br> <br>
        <label> Lastname: </label>
        <input type="text" name="lastname" size="15"/> <br> <br>
        <br>
        <label>
        Phone :
    </label>
    <input type="text" name="country code"  value="+256" size="2"/>
    <input type="text" name="phone" size="10"/> <br> <br>
        Address:
        <textarea cols="80" rows="5" value="address">
        </textarea>
        <br> <br>
        Email:
    <input type="email" id="email" name="email"/> <br>
    <br> <br>
        <input type="button" value="Submit"/>
    </form>
    </div>
</body>
</html>
