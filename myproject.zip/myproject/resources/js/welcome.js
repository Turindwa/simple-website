// welcome.js

function showLoginPage() {
    console.log("showLoginPage() function is called!");
    // Hide the welcome section
    const welcomeSection = document.querySelector(".welcome");
    welcomeSection.style.display = "none";

    // Show the login page section
    const loginSection = document.getElementById("loginSection");
    loginSection.style.display = "block";

    const loginPage = document.createElement("iframe");
    loginPage.src = "/login.html";
    loginPage.style.width = "100%";
    loginPage.style.height = "100vh";
    loginSection.appendChild(loginPage); // Append the <iframe> to the "loginSection" <div>
}
