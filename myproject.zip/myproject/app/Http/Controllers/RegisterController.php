<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;

class RegisterController extends Controller
{
    public function store(Request $request)
    {
        // Validate the form data
        $validatedData = $request->validate([
            'firstname' => 'required|string|max:255',
            'middlename' => 'nullable|string|max:255',
            'lastname' => 'required|string|max:255',
            'phone' => 'required|string|max:255',
            'address' => 'required|string',
            'email' => 'required|email|unique:users|max:255',
        ]);

        // Create a new user and store the data in the database
        User::create($validatedData);

        // Redirect the user to a thank you page or any other page after successful registration
        return redirect()->route('thankyou');
        //
    }
}
