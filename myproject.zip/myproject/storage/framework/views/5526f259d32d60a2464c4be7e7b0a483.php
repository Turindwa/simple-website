<Html>
    <head>
    <title>
    Registration Page
    </title>
    </head>

    <body style = "color:black">
    <br>
    <br>
    <form action="<?php echo e(route('register.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
    <label> Firstname </label>
    <input type="text" name="firstname" size="15"/> <br> <br>
    <label> Middlename: </label>
    <input type="text" name="middlename" size="15"/> <br> <br>
    <label> Lastname: </label>
    <input type="text" name="lastname" size="15"/> <br> <br>

    <label>
    Country :
    </label>
    <select>
    <option value="Course">Uganda</option>
    <option value="BCA">Kenya</option>
    <option value="BBA">Tanzania</option>
    <option value="B.Tech">Rwanda</option>
    <option value="MBA">Burundi</option>
    <option value="MCA">Congo</option>
    </select>

    <br>
    <br>
    <label>
    Gender :
    </label><br>
    <input type="radio" name="male"/> Male <br>
    <input type="radio" name="female"/> Female <br>
    <input type="radio" name="other"/> Other
    <br>
    <br>

    <label>
    Phone :
    </label>
    <input type="text" name="country code"  value="+256" size="2"/>
    <input type="text" name="phone" size="10"/> <br> <br>
    Address:
    <br>
    <textarea cols="80" rows="5" value="address">
    </textarea>
    <br> <br>
    Email:
    <input type="email" id="email" name="email"/> <br>
    <br> <br>
    Password:
    <input type="Password" id="pass" name="pass"> <br>
    <br> <br>
    Comfirm password:
    <input type="Password" id="repass" name="repass"> <br> <br>
    <input type="button" value="Submit"/>
    </form>
    </body>
    </html>
<?php /**PATH C:\xampp\htdocs\myproject\myproject\resources\views/register.blade.php ENDPATH**/ ?>