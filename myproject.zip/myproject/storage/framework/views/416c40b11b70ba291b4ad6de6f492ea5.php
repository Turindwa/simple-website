<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to My Website</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/welcome.css')); ?>">
    <style>
        /* Set background image for the entire page */
        body {
            background-image: url("/images/background.jpg");
            background-size: cover; /* Adjust the image size to cover the entire body */
            margin: 0;
            padding: 0;
            background-repeat: no-repeat;
            background-attachment: fixed;


        }

        /* Add any other custom styles for your page elements here */
        h1 {
            color: #333;
        }
        .home-button {
        background-color: red;
        color: white;
        padding: 10px 20px;
        border-radius: 50px;
        cursor: pointer;
        margin-right: 10px;
    }

    /* Style for Login button */
    .login-button {
        background-color: blue;
        color: white;
        padding: 10px 20px;
        border-radius: 50px;
        cursor: pointer;
        margin-right: 10px;
    }
    .register-button {
        background-color: green;
        color: white;
        padding: 10px 20px;
        border-radius: 50px;
        cursor: pointer;
        margin-right: 10px;
    }
    header {
        display: flex; /* Use flexbox to align elements horizontally */
        justify-content: flex-end; /* Align navigation elements to the right side */
        align-items: flex-start; /* Align navigation elements to the upper part */
        padding: 20px;
    }


        /* Add more styles for other elements as needed */
    </style>
</head>

<body>
    <header class="header">
        <nav>

            <button class="home-button" onclick="window.location.href='/homepage';">Home</button>
            <button class="login-button" onclick="window.location.href='/login';">Login</button>
            <button  class="register-button" onclick="window.location.href='/register';">Register</button>

        </nav>
    </header>

    <section class="welcome">
        <div class="welcome-text">
            <h1>Welcome to  your number one waste collection services across the country!</h1>
            <p>Please make us your first choice as we take care of all the rubbish around you.</p>
            <p> click register if its your first time here to create an account with us.</p>
        </div>
    </section>
    <div id="loginSection" style="display: none;"></div>
    <script src="<?php echo e(asset('js/welcome.js')); ?>"></script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\myproject\myproject\resources\views/my.blade.php ENDPATH**/ ?>